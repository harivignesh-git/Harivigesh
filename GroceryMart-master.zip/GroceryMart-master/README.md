# GroceryMart
It is an Online Grocery Shopping web application developed using HTML, CSS, Bootstrap and JavaScript. It is completely dynamic in nature. 
Items can be added into cart in any quantity and then total bill is generated. User can like the item, add it to favourites and wishlist as well.
